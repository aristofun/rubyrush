class Film
  def initialize(file_path)
    lines = File.readlines(file_path, chomp: true)

    @title = lines[0]
    @director = lines[1]
    @year = lines[2]
  end

  def director
    return @director
  end

  def to_s
    return "#{@title} (#{@director}, #{@year})"
  end
end
