require_relative "film.rb"

# Понять, какие текстовые файлы в папке data
file_paths = Dir.glob("data/*.txt")

# Прочитать все эти файлы (Название, режиссер, год)
# films = []

# file_paths.each do |file_path|
#   films << Film.new(file_path)
# end

films = file_paths.map { |file_path| Film.new(file_path) }

# Найти всех режиссеров (без повторов)
# directors = []

# films.each do |film|
#   directors << film.director
# end

# directors = directors.uniq

directors = films.map { |film| film.director }.uniq

# Вывести режиссеров на экран
directors.each_with_index do |director, index|
  puts "#{index + 1}: #{director}"
end

# Спросить у пользователя, какого выбрать
puts "Фильм какого режиссера Вы хотите посмотреть?"
user_director_index = gets.to_i
director_name = directors[user_director_index - 1]

# Выбрать произвольный фильм этого режиссера
# films_by_director = []

# films.each do |film|
#   if film.director == director_name
#     films_by_director << film
#   end
# end

films_by_director = films.select do |film|
  film.director == director_name
end

puts films_by_director.sample
