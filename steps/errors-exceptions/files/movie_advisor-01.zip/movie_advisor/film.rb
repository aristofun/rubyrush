class Film
  def initialize(title, director, year)
    @title = title
    @director = director
    @year = year
  end

  def director
    return @director
  end

  def to_s
    return "#{@title} (#{@director}, #{@year})"
  end
end
