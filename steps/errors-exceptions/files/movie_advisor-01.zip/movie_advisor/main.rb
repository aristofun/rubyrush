require_relative "film.rb"

# Понять, какие текстовые файлы в папке data
file_paths = Dir.glob("data/*.txt")

# Прочитать все эти файлы (Название, режиссер, год)
films = []

file_paths.each do |file_path|
  lines = File.readlines(file_path, chomp: true)

  film = Film.new(lines[0], lines[1], lines[2])

  films << film
end

# Найти всех режиссеров (без повторов)
directors = []

films.each do |film|
  directors << film.director
end

directors = directors.uniq

# Вывести режиссеров на экран
directors.each_with_index do |director, index|
  puts "#{index + 1}: #{director}"
end

# Спросить у пользователя, какого выбрать
puts "Фильм какого режиссера Вы хотите посмотреть?"
user_director_index = gets.to_i
director_name = directors[user_director_index - 1]

# Выбрать произвольный фильм этого режиссера
films_by_director = []

films.each do |film|
  if film.director == director_name
    films_by_director << film
  end
end

puts films_by_director.sample
